at now  << OEF
shutdown -Fr
rm /tmp/rebootscript.sh
EOF
